package ca.mcgill.ecse211.lab4;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import ca.mcgill.ecse211.odometer.Odometer;
import lejos.hardware.Sound;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.lcd.LCD;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.robotics.SampleProvider;
import lejos.utility.Delay;

public class UltrasonicLocalizer {
	public enum LocalizationType{fallingEdge, risingEdge};
	private EV3LargeRegulatedMotor leftMotor;
	private EV3LargeRegulatedMotor rightMotor;
	private EV3UltrasonicSensor usSensor;
	private Odometer odometer;
	private LocalizationType type;
	private static final int FORWARD_SPEED = 200;
	private static final int ROTATE_SPEED =100;
	private static final int DETECT_DISTANCE = 40;
	private double distance[];
	
	
	public UltrasonicLocalizer(EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor, LocalizationType type,
			Odometer odometer) {
		this.leftMotor = leftMotor;
		this.rightMotor = rightMotor;
		this.type = type;
		this.odometer = odometer;
		this.usSensor = new EV3UltrasonicSensor(LocalEV3.get().getPort("S4"));
		
	}
	
	
	public void UltrasonicLocalization() {
		double alpha, beta;
		//rising edge
		if(type == LocalizationType.risingEdge) {
			leftMotor.setSpeed(ROTATE_SPEED);
			rightMotor.setSpeed(ROTATE_SPEED);
			leftMotor.forward();
			rightMotor.backward();
			while(true) {
				if(getDistance() < DETECT_DISTANCE) {
					break;
				}
			}
			//rotate to the left until it detects a rising edge
			while(true) {
				if(getDistance() > DETECT_DISTANCE) {
					Sound.beep();
					leftMotor.stop();
					rightMotor.stop();
					alpha = odometer.getT();
					break;
				}
			}
			leftMotor.setSpeed(ROTATE_SPEED);
			rightMotor.setSpeed(ROTATE_SPEED);
			leftMotor.backward();
			rightMotor.forward();
			Delay.msDelay(1000);
			sleep(1000);
			//keep rotating to the left until it sees a wall
			while(true) {
				if(getDistance() > DETECT_DISTANCE) {
					Sound.beep();
					leftMotor.stop();
					rightMotor.stop();
					beta = odometer.getT();
					break;
				}
			}
			if(alpha < beta) {
				odometer.setTheta((45-(alpha+beta)/2) + odometer.getT());
			}
			else {
				odometer.setTheta((225-(alpha+beta)/2) + odometer.getT());
			}
			turnTo(0);			
		}
		//falling edge
		else{
			leftMotor.setSpeed(ROTATE_SPEED);
			rightMotor.setSpeed(ROTATE_SPEED);
			leftMotor.backward();
			rightMotor.forward();
			//rotate to the left until it detects a rising edge
			while(true) {
				if(getDistance() > DETECT_DISTANCE) {
					break;
				}
			}
			while(true) {
				if(getDistance() < DETECT_DISTANCE) {
					Sound.beep();
					leftMotor.stop();
					rightMotor.stop();
					alpha = odometer.getT();
					break;
				}
			}
			leftMotor.setSpeed(ROTATE_SPEED);
			rightMotor.setSpeed(ROTATE_SPEED);
			leftMotor.forward();
			rightMotor.backward();
			Delay.msDelay(1000);
			sleep(1000);
			//keep rotating to the left until it sees a wall
			while(true) {
				if(getDistance() < DETECT_DISTANCE) {
					Sound.beep();
					leftMotor.stop();
					rightMotor.stop();
					beta = odometer.getT();
					break;
				}
			}
			if(alpha < beta) {
				odometer.setTheta((45-(alpha+beta)/2) + odometer.getT());
			}
			else {
				odometer.setTheta((225-(alpha+beta)/2) + odometer.getT());
			}
			turnTo(0);			
		}
		
	}
	public void turnTo(double theta) {
		double turnAngle;
		turnAngle = theta - odometer.getT();
		//calculate the minimal angle
		if(turnAngle < -180) {
			turnAngle = turnAngle + 360;
		}
		else if(turnAngle > 180) {
			turnAngle = turnAngle - 360;
		}
		leftMotor.setSpeed(ROTATE_SPEED);
		rightMotor.setSpeed(ROTATE_SPEED);
		leftMotor.rotate(convertAngle(Lab4.WHEEL_RAD, Lab4.TRACK, turnAngle), true);
		rightMotor.rotate(-convertAngle(Lab4.WHEEL_RAD, Lab4.TRACK, turnAngle), false);
	}
	
	private static int convertAngle(double radius, double width, double angle) {
		return convertDistance(radius, Math.PI * width * angle / 360.0);
	}
	private static int convertDistance(double radius, double distance) {
		return (int) ((180.0 * distance) / (Math.PI * radius));
	}
	
	public double getDistance() {
		SampleProvider sampleProvider = usSensor.getMode("Distance"); // usDistance provides samples from
        // this instance
		float[] usDistance = new float[3];
		List<Double> distance = new ArrayList<Double>();
		//sampleProvider.fetchSample(usDistance, 0);
		for(int i = 0; i < 9; i++) {
			sampleProvider.fetchSample(usDistance, 0);
			LCD.drawString("us Distance: " + usDistance[0], 0, 5);
			//distance[i] = usDistance[0]*100;
			distance.add((double)usDistance[0]*100);
			Delay.msDelay(30);
		}
		Collections.sort(distance);
		return distance.get(9/2);
	}
	public static void sleep(int time) {
		long a = System.currentTimeMillis();
		long b = System.currentTimeMillis();
		while( (b-a) <= time) {
			b = System.currentTimeMillis();
		}
	}
}
