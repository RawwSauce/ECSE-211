/*
 * OdometryCorrection.java
 */
package ca.mcgill.ecse211.odometer;

import lejos.hardware.Sound;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.lcd.LCD;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.robotics.Color;
import lejos.robotics.SampleProvider;

public class OdometryCorrection implements Runnable {
  private static final long CORRECTION_PERIOD = 10;
  private Odometer odometer;
  
  private EV3ColorSensor cSensor;
  private int lineNum;
  
  private static SampleProvider sampleProvider;
  private static int sampleSize;
  
  //private float[] colorSample;

  /**
   * This is the default class constructor. An existing instance of the odometer is used. This is to
   * ensure thread safety.
   * 
   * @throws OdometerExceptions
   */
  public OdometryCorrection() throws OdometerExceptions {

    this.odometer = Odometer.getOdometer();
    this.cSensor = new EV3ColorSensor(LocalEV3.get().getPort("S2"));
  }

  /**
   * Here is where the odometer correction code should be run.
   * 
   * @throws OdometerExceptions
   */
  // run method (required for Thread)
  public void run() {
    long correctionStart, correctionEnd;

    while (true) {
      correctionStart = System.currentTimeMillis();

      // TODO Trigger correction (When do I have information to correct?)
      
      cSensor.setFloodlight(lejos.robotics.Color.RED);
      
      sampleProvider = cSensor.getRGBMode();
      sampleSize = sampleProvider.sampleSize();
      float []colorSample = new float[sampleSize];
    		  
      sampleProvider.fetchSample(colorSample, 0);
      LCD.drawString("R: " + colorSample[0] , 0, 4);
      LCD.drawString("G: " + colorSample[1], 0, 5);
      LCD.drawString("B: " + colorSample[2], 0, 6);
      
      //System.out.print("color intensity is: " + colorSample[0]);
      
      if(colorSample[0]< 0.1 && colorSample[1] < 0.7 && colorSample[2] < 0.6) {
    	  	Sound.playTone(150, 250);
    	  	//Sound.beep();
    	  	lineNum++;
    	  	switch(lineNum) {
    	  		//moves North
    	  		case 1: 	odometer.setY(0);
    	  				odometer.setTheta(0);
    	  				break;
    	  		case 2:	odometer.setY(30.48);
    	  				odometer.setTheta(0);
    	  				break;
    	  		//moves East
    	  		case 3:	odometer.setX(0);
    	  				odometer.setTheta(90);
    	  				break;
    	  		case 4:	odometer.setX(30.48);
    	  				odometer.setTheta(90);
    	  				break;
    	  		//moves South:
    	  		case 5:	odometer.setY(30.48);
    	  				odometer.setTheta(180);
    	  				break;
    	  		case 6:	odometer.setY(0);
    	  				odometer.setTheta(180);
    	  				break;
    	  		//moves West
    	  		case 7:	odometer.setX(30.48);
    	  				odometer.setTheta(270);
    	  				break;	
    	  		case 8:	odometer.setX(0);
    	  				odometer.setTheta(270);
    	  				break;
    	  			
    	  	}
      }
      // TODO Calculate new (accurate) robot position

      // TODO Update odometer with new calculated (and more accurate) vales

      //odometer.setXYT(0.3, 19.23, 5.0);

      // this ensure the odometry correction occurs only once every period
      correctionEnd = System.currentTimeMillis();
      if (correctionEnd - correctionStart < CORRECTION_PERIOD) {
        try {
          Thread.sleep(CORRECTION_PERIOD - (correctionEnd - correctionStart));
        } catch (InterruptedException e) {
          // there is nothing to be done here
        }
      }
    }
  }
}
